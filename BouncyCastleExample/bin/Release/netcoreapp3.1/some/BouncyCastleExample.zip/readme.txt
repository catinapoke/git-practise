Подготовка: В msg.txt пишеться случайный текст для проверки

Запуск примера(start.bat) - BouncyCastleExample.exe someID somePassPhrase

Сгенерированные файлы:
В crypted.txt - зашифрованное сообщение
В decrypted.txt - расшифрованное сообщение
В pub.asc - публичный ключ
В secret.asc - секретный ключ
